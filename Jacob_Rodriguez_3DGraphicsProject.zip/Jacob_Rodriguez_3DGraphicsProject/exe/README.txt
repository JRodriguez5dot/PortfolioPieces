up & down arrow = change fov

hold right click to look around

wasd [shift] [space] = move camera


adjust window to get rid of green sliver at the top when it starts.