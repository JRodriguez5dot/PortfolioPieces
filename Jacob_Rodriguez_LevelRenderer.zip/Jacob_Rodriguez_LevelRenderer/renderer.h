// minimalistic code to draw a single triangle, this is not part of the API.
#include "shaderc/shaderc.h" // needed for compiling shaders at runtime
#include "../Dependencies/h2bParser.h"
#include <fstream>
#include <chrono>
#include <cassert>
//#include <chrono>
#ifdef _WIN32 // must use MT platform DLL libraries on windows
#pragma comment(lib, "shaderc_combined.lib") 
#endif
// Simple Vertex Shader
const char* vertexShaderSource = R"(
// TODO: Part 2i
#pragma pack_matrix(row_major)
// an ultra simple hlsl vertex shader
// TODO: Part 2b
struct OBJ_ATTRIBUTES{
	float3		Kd; // diffuse reflectivity
	float	    d; // dissolve (transparency) 
	float3		Ks; // specular reflectivity
	float       Ns; // specular exponent
	float3		Ka; // ambient reflectivity
	float       sharpness; // local reflection map sharpness
	float3		Tf; // transmission filter
	float       Ni; // optical density (index of refraction)
	float3		Ke; // emissive reflectivity
	uint    illum; // illumination model

};
struct SHADER_MODEL_DATA {
		matrix matricies; // world matrix
		OBJ_ATTRIBUTES materials[200]; // color/texture of surface
	};
struct ALL_SHADER_MODEL_DATA {
		float4 lightDirection;	
		float4 lightColor;

		matrix spotLights[2];
		float4 spotLightDirection;
		float4 spotColor; 
		float4 pointColor;
		matrix pointLights[2];

		matrix projectionMatrix; // view info

		SHADER_MODEL_DATA ModelData[20]; //model info
};
StructuredBuffer<ALL_SHADER_MODEL_DATA> SceneData;
// TODO: Part 4g
// TODO: Part 2i
// TODO: Part 3e
// For push_constants to work in HLSL you mus prepend this to a cbuffer
[[vk::push_constant]]
cbuffer MESH_INDEX {
	float4 cameraPos;
	matrix viewMatrix;
	uint mesh_ID;
	uint model_ID;
	float fluff[14];
};
// TODO: Part 4a
// TODO: Part 1f
struct InVertex{
	float3 pos : POSITION;
	float3 uvw : TEXCOORD;
	float3 nrm : NORMAL;
};
struct OutVertex{
	float4 pos : SV_POSITION;
	float3 uvw : TEXCOORD;
	float3 nrm : NORMAL;
	float3 worldPos : POSITION;
};
// TODO: Part 4b
OutVertex main(InVertex input) : SV_POSITION
{
	
	OutVertex output = (OutVertex)0;
	output.pos = float4(input.pos, 1);
	output.uvw = input.uvw;
	output.nrm = mul(float4(input.nrm, 0.0f), SceneData[0].ModelData[model_ID].matricies).xyz;
	// TODO: Part 2i
	output.pos = mul(output.pos, SceneData[0].ModelData[model_ID].matricies);
	output.worldPos = output.pos;
	output.pos = mul(output.pos, viewMatrix);
	output.pos = mul(output.pos, SceneData[0].projectionMatrix);
	return output;
		// TODO: Part 4e
	// TODO: Part 4b
		// TODO: Part 4e
}
//float4 main() : SV_POSITION
//{
//	
//	return float4(0,0,0,0);
//}
)";
// Simple Pixel Shader
const char* pixelShaderSource = R"(
struct OBJ_ATTRIBUTES{
	float3		Kd; // diffuse reflectivity
	float	    d; // dissolve (transparency) 
	float3		Ks; // specular reflectivity
	float       Ns; // specular exponent
	float3		Ka; // ambient reflectivity
	float       sharpness; // local reflection map sharpness
	float3		Tf; // transmission filter
	float       Ni; // optical density (index of refraction)
	float3		Ke; // emissive reflectivity
	uint    illum; // illumination model

};
struct SHADER_MODEL_DATA {
		matrix matricies; // world matrix
		OBJ_ATTRIBUTES materials[200]; // color/texture of surface
	};
struct ALL_SHADER_MODEL_DATA {
		float4 lightDirection;	
		float4 lightColor;

		matrix spotLights[2];
		float4 spotLightDirection;
		float4 spotColor; 
		float4 pointColor;
		matrix pointLights[2];

		matrix projectionMatrix; // view info

		SHADER_MODEL_DATA ModelData[20]; //model info
};
StructuredBuffer<ALL_SHADER_MODEL_DATA> SceneData : register (b0);


// For push_constants to work in HLSL you must prepend this to a cbuffer
[[vk::push_constant]]
cbuffer MESH_INDEX {
	float4 cameraPos;
	matrix viewMatrix;
	uint mesh_ID;
	uint model_ID;
	float fluff[14];
};

// an ultra simple hlsl pixel shader
// TODO: Part 4b

struct InPixel{
	float4 pos : SV_POSITION;
	float3 uvw : TEXCOORD;
	float3 nrm : NORMAL;
	float3 worldPos : POSITION;
};
float4 main(InPixel input) : SV_TARGET 
{	
	float4 SURFACE_COLOR = float4(SceneData[0].ModelData[model_ID].materials[mesh_ID].Kd, 1); // TODO: Part 1a
	if (SURFACE_COLOR.a < 0.2) {
		discard;
	}

	input.nrm = normalize(input.nrm);

	float4 DIR_LIGHT_COLOR = SceneData[0].lightColor;
	float3 DIR_LIGHT_DIRECTION = float3(SceneData[0].lightDirection.x, SceneData[0].lightDirection.y, SceneData[0].lightDirection.z);
	DIR_LIGHT_DIRECTION = normalize(DIR_LIGHT_DIRECTION);
	
	float DIR_LIGHT_ANGLE = dot(-DIR_LIGHT_DIRECTION, input.nrm);
	
	float4 FINAL_DIR_LIGHT = SURFACE_COLOR * DIR_LIGHT_COLOR * DIR_LIGHT_ANGLE * 2.0f;

	float3 REFLECTED = reflect(DIR_LIGHT_DIRECTION, input.nrm);
	float3 CAMERA_POSITION = float3(cameraPos.xyz);
	float3 TO_CAM = normalize(CAMERA_POSITION - input.worldPos);
	float4 SURFACE_SPEC_COLOR = float4(SceneData[0].ModelData[model_ID].materials[mesh_ID].Ks, 1);
	
	// point light
	float3 POINT_LIGHT_POSITION = float3(SceneData[0].pointLights[0]._m30, SceneData[0].pointLights[0]._m31, SceneData[0].pointLights[0]._m32);
	float POINT_LIGHT_RADIUS = 13.0f;
	float4 POINT_LIGHT_COLOR = SceneData[0].pointColor;
	
	// spot light
	float4 SPOT_LIGHT_COLOR = SceneData[0].spotColor;
	float3 SPOT_LIGHT_POSITION = float3(SceneData[0].spotLights[0]._m30, SceneData[0].spotLights[0]._m31, SceneData[0].spotLights[0]._m32);
	float3 CONE_DIRECTION = float3(SceneData[0].spotLightDirection.x, SceneData[0].spotLightDirection.y, SceneData[0].spotLightDirection.z);
	CONE_DIRECTION = normalize(CONE_DIRECTION);
	float SPOT_OUTER_CONE_RATIO = 9.98f;
	float SPOT_INNER_CONE_RATIO = 9.99f;
	float SPOT_LIGHT_RADIUS = 25.0f;

	float4 AMBIENT_TERM = DIR_LIGHT_COLOR * 0.1f;

	

	float3 POINT_LIGHT_DIRECTION = input.worldPos - POINT_LIGHT_POSITION;
	float POINT_LIGHT_DISTANCE = length(POINT_LIGHT_DIRECTION);
	POINT_LIGHT_DIRECTION /= POINT_LIGHT_DISTANCE;
	
	float POINT_LIGHT_ANGLE = dot(-POINT_LIGHT_DIRECTION, input.nrm);
	float POINT_LIGHT_ATTENUATION = 1 - saturate(POINT_LIGHT_DISTANCE / POINT_LIGHT_RADIUS);
	POINT_LIGHT_ATTENUATION *= POINT_LIGHT_ATTENUATION;
	
	float4 FINAL_POINT_LIGHT = SURFACE_COLOR * POINT_LIGHT_COLOR * POINT_LIGHT_ATTENUATION * POINT_LIGHT_ANGLE;
	
	float3 SPOT_LIGHT_DIRECTION = normalize(input.worldPos - SPOT_LIGHT_POSITION);
	float SPOT_SURFACE_RATIO = saturate(dot(SPOT_LIGHT_DIRECTION, CONE_DIRECTION));
	
	float SPOT_LIGHT_RATIO = saturate(-dot(SPOT_LIGHT_DIRECTION, input.nrm));
	float SPOT_CONE_ATTENUATION =
		1.0f - saturate((SPOT_INNER_CONE_RATIO - SPOT_SURFACE_RATIO) / (SPOT_INNER_CONE_RATIO - SPOT_OUTER_CONE_RATIO));
	
	//float SPOT_LIGHT_DISTANCE = length(SPOT_LIGHT_DIRECTION);
	//float SPOT_LIGHT_ATTENUATION = 1 - saturate(SPOT_LIGHT_DISTANCE / SPOT_LIGHT_RADIUS);
	
	//SPOT_CONE_ATTENUATION *= SPOT_LIGHT_ATTENUATION;
	SPOT_CONE_ATTENUATION *= SPOT_CONE_ATTENUATION;
	
	
	float4 FINAL_SPOT_LIGHT = SPOT_LIGHT_RATIO * SPOT_LIGHT_COLOR * SURFACE_COLOR * SPOT_CONE_ATTENUATION;
	
	float SPEC_DOT = saturate(dot(REFLECTED, TO_CAM));
	SPEC_DOT = pow(SPEC_DOT, 3.0f);
	
	float4 FINAL_SPEC_LIGHT = float4(1,1,1,1) * SURFACE_SPEC_COLOR * SPEC_DOT;

	float4 FINAL_COLOR = FINAL_DIR_LIGHT + FINAL_SPEC_LIGHT + AMBIENT_TERM + FINAL_POINT_LIGHT + FINAL_SPOT_LIGHT;

	return FINAL_COLOR;
}
)";


class Model {
public:
	struct Vertex {
		float pos[3];
		float uvw[3];
		float nrm[3];
	};


	struct material {
		H2B::ATTRIBUTES attrib; // Surface shading characteristics & illumination model
	// All items below this line are not needed on the GPU and are generally only used during load time.
		const char* name; // the name of this material
		// If the model's materials contain any specific texture data it will be located below.
		const char* map_Kd; // diffuse texture
		const char* map_Ks; // specular texture
		const char* map_Ka; // ambient texture
		const char* map_Ke; // emissive texture
		const char* map_Ns; // specular exponent texture
		const char* map_d; // transparency texture
		const char* disp; // roughness map (displacement)
		const char* decal; // decal texture (lerps texture & material colors)
		const char* bump; // normal/bumpmap texture
		void* padding[2]; // 16 byte alignment on 32bit or 64bit
	};

	struct Mesh {
		const char* name;
		unsigned    indexCount;
		unsigned    indexOffset;
		unsigned    materialIndex;
	};

	struct SHADER_MODEL_DATA {
		GW::MATH::GMATRIXF matricies; // world space 
		H2B::ATTRIBUTES materials[200]; // color/texture of surface
	};



	H2B::Parser keanu;

	std::string name;

	GW::MATH::GMATRIXF worldMatrix;

	std::vector<Vertex> vertices;
	unsigned vertexCount;

	std::vector<unsigned> indices;
	unsigned indexCount;

	std::vector<material> materials;
	unsigned materialCount;

	std::vector<Mesh> meshData;
	unsigned meshCount;

	SHADER_MODEL_DATA uniform;

	unsigned ModelID;

	VkBuffer vHandle;
	VkDeviceMemory vData;

	VkBuffer iHandle;
	VkDeviceMemory iData;





	void CopyFromH2B(const char* s, GW::MATH::GMATRIXF& world) {


		keanu.Parse(s);

		worldMatrix = world;

		vertexCount = keanu.vertexCount;

		indexCount = keanu.indexCount;

		materialCount = keanu.materialCount;

		meshCount = keanu.meshCount;


		vertices.resize(vertexCount);
		for (int i = 0; i < vertexCount; i++)
		{
			vertices[i].pos[0] = keanu.vertices[i].pos.x;
			vertices[i].pos[1] = keanu.vertices[i].pos.y;
			vertices[i].pos[2] = keanu.vertices[i].pos.z;
			vertices[i].uvw[0] = keanu.vertices[i].uvw.x;
			vertices[i].uvw[1] = keanu.vertices[i].uvw.y;
			vertices[i].uvw[2] = keanu.vertices[i].uvw.z;
			vertices[i].nrm[0] = keanu.vertices[i].nrm.x;
			vertices[i].nrm[1] = keanu.vertices[i].nrm.y;
			vertices[i].nrm[2] = keanu.vertices[i].nrm.z;
		}

		indices.resize(indexCount);
		for (int i = 0; i < indexCount; i++)
		{
			indices[i] = keanu.indices[i];
		}

		materials.resize(materialCount);
		for (int i = 0; i < materialCount; i++)
		{

			materials[i].attrib = keanu.materials[i].attrib;
			materials[i].name = keanu.materials[i].name;
			materials[i].map_Kd = keanu.materials[i].map_Kd;
			materials[i].map_Ks = keanu.materials[i].map_Ks;
			materials[i].map_Ka = keanu.materials[i].map_Ka;
			materials[i].map_Ke = keanu.materials[i].map_Ke;
			materials[i].map_Ns = keanu.materials[i].map_Ns;
			materials[i].map_d = keanu.materials[i].map_d;
			materials[i].disp = keanu.materials[i].disp;
			materials[i].decal = keanu.materials[i].decal;
			materials[i].bump = keanu.materials[i].bump;
		}

		meshData.resize(meshCount);
		for (int i = 0; i < meshCount; i++)
		{
			meshData[i].name = keanu.meshes[i].name;
			meshData[i].indexOffset = keanu.meshes[i].drawInfo.indexOffset;
			meshData[i].indexCount = keanu.meshes[i].drawInfo.indexCount;
			meshData[i].materialIndex = keanu.meshes[i].materialIndex;
		}

		for (int i = 0; i < materialCount; i++)
		{
			uniform.materials[i] = materials[i].attrib;
		}

		uniform.matricies = world;
	}
};


// Creation, Rendering & Cleanup
class Renderer
{
	// proxy handles
	GW::SYSTEM::GWindow win;
	GW::GRAPHICS::GVulkanSurface vlk;
	GW::CORE::GEventReceiver shutdown;


	// TODO: Part 4a
	GW::INPUT::GInput mkb;
	GW::INPUT::GController xbox;

	GW::MATH::GMatrix math;
	GW::MATH::GVector math2;


	/////////////////////////////////

#define MAX_MODELS_IN_SCENE 20
#define MAX_TYPE_OF_LIGHTS 2
	struct ALL_SHADER_MODEL_DATA {
		GW::MATH::GVECTORF lightDirection, lightColor; // lighting info

		GW::MATH::GMATRIXF spotLights[MAX_TYPE_OF_LIGHTS];
		GW::MATH::GVECTORF spotLightDirection, spotColor, pointColor;
		GW::MATH::GMATRIXF pointLights[MAX_TYPE_OF_LIGHTS];

		GW::MATH::GMATRIXF projectionMatrix; // view info

		Model::SHADER_MODEL_DATA ModelData[MAX_MODELS_IN_SCENE]; //model info

	};

	GW::MATH::GMATRIXF TheCamera;
	GW::MATH::GMATRIXF viewMatrix;
	GW::MATH::GMATRIXF projectionMatrix;

	std::vector<Model> models;
	std::vector<GW::MATH::GMATRIXF> spotLights;
	std::vector<GW::MATH::GMATRIXF> pointLights;


	std::vector<VkBuffer> constantBuffers;
	std::vector<VkDeviceMemory> constantData;

	ALL_SHADER_MODEL_DATA push;

	////////////////////////////////// Descriptor

	VkDescriptorSetLayout setlayoutdesc = nullptr;
	// TODO: Part 2f
	VkDescriptorPool daPool = nullptr;
	std::vector<VkDescriptorSet> daSet;

	//////////////////////////////////

	// what we need at a minimum to draw a triangle
	VkDevice device = nullptr;
	VkShaderModule vertexShader = nullptr;
	VkShaderModule pixelShader = nullptr;
	// pipeline settings for drawing (also required)
	VkPipeline pipeline = nullptr;
	VkPipelineLayout pipelineLayout = nullptr;
public:

	void ReadGameLevel(std::string level_file) {
		std::ifstream file;
		file.open(level_file);
		if (file.is_open()) {
			/*std::cout << level_file << " opened." << std::endl;*/
			while (!file.eof()) {

				char buffer[1024];
				file.getline(buffer, 1024, '\n');
				if (strcmp(buffer, "MESH") == 0) {
					file.getline(buffer, 1024, '\n');
					std::string name = buffer;
					std::cout << name << std::endl;
					name = name.substr(0, name.find_last_of("."));

					name += ".h2b";
					name = "../Assets/" + name;
					std::cout << name << std::endl;
					GW::MATH::GMATRIXF modelWorldmatrix = GW::MATH::GIdentityMatrixF;

					file.getline(buffer, 1024, '\n');
					/*std::cout << buffer << std::endl;*/
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &modelWorldmatrix.row1.x, &modelWorldmatrix.row1.y, &modelWorldmatrix.row1.z, &modelWorldmatrix.row1.w);
					std::cout << modelWorldmatrix.row1.x << " " << modelWorldmatrix.row1.y << " " << modelWorldmatrix.row1.z << " " << modelWorldmatrix.row1.w << std::endl;

					file.getline(buffer, 1024, '\n');
					/*std::cout << buffer << std::endl;*/
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &modelWorldmatrix.row2.x, &modelWorldmatrix.row2.y, &modelWorldmatrix.row2.z, &modelWorldmatrix.row2.w);
					std::cout << modelWorldmatrix.row2.x << " " << modelWorldmatrix.row2.y << " " << modelWorldmatrix.row2.z << " " << modelWorldmatrix.row2.w << std::endl;

					file.getline(buffer, 1024, '\n');
					/*std::cout << buffer << std::endl;*/
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &modelWorldmatrix.row3.x, &modelWorldmatrix.row3.y, &modelWorldmatrix.row3.z, &modelWorldmatrix.row3.w);
					std::cout << modelWorldmatrix.row3.x << " " << modelWorldmatrix.row3.y << " " << modelWorldmatrix.row3.z << " " << modelWorldmatrix.row3.w << std::endl;

					file.getline(buffer, 1024, '\n');
					/*std::cout << buffer << std::endl;*/
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &modelWorldmatrix.row4.x, &modelWorldmatrix.row4.y, &modelWorldmatrix.row4.z, &modelWorldmatrix.row4.w);

					std::cout << modelWorldmatrix.row4.x << " " << modelWorldmatrix.row4.y << " " << modelWorldmatrix.row4.z << " " << modelWorldmatrix.row4.w << std::endl;


					// create model with name and matrix;
					Model newModel;
					const char* path = name.c_str();
					newModel.CopyFromH2B(path, modelWorldmatrix);
					models.push_back(newModel);

					std::cout << "MESH READ" << std::endl;
				}
				else if (strcmp(buffer, "CAMERA") == 0) {

					GW::MATH::GMATRIXF camera = GW::MATH::GIdentityMatrixF;
					file.getline(buffer, 1024, '\n');
					std::string name = buffer;
					std::cout << name << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &camera.row1.x, &camera.row1.y, &camera.row1.z, &camera.row1.w);
					std::cout << camera.row1.x << " " << camera.row1.y << " " << camera.row1.z << " " << camera.row1.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &camera.row2.x, &camera.row2.y, &camera.row2.z, &camera.row2.w);
					std::cout << camera.row2.x << " " << camera.row2.y << " " << camera.row2.z << " " << camera.row2.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &camera.row3.x, &camera.row3.y, &camera.row3.z, &camera.row3.w);
					std::cout << camera.row3.x << " " << camera.row3.y << " " << camera.row3.z << " " << camera.row3.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &camera.row4.x, &camera.row4.y, &camera.row4.z, &camera.row4.w);

					std::cout << camera.row4.x << " " << camera.row4.y << " " << camera.row4.z << " " << camera.row4.w << std::endl;

					TheCamera = camera;

					std::cout << "CAMERA READ" << std::endl;
				}
				else if (strcmp(buffer, "LIGHT") == 0) {


					file.getline(buffer, 1024, '\n');
					std::string name = buffer;
					std::cout << name << std::endl;
					name = name.substr(0, name.find_last_of("."));


					GW::MATH::GMATRIXF lightpos = GW::MATH::GIdentityMatrixF;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &lightpos.row1.x, &lightpos.row1.y, &lightpos.row1.z, &lightpos.row1.w);
					std::cout << lightpos.row1.x << " " << lightpos.row1.y << " " << lightpos.row1.z << " " << lightpos.row1.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &lightpos.row2.x, &lightpos.row2.y, &lightpos.row2.z, &lightpos.row2.w);
					std::cout << lightpos.row2.x << " " << lightpos.row2.y << " " << lightpos.row2.z << " " << lightpos.row2.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &lightpos.row3.x, &lightpos.row3.y, &lightpos.row3.z, &lightpos.row3.w);
					std::cout << lightpos.row3.x << " " << lightpos.row3.y << " " << lightpos.row3.z << " " << lightpos.row3.w << std::endl;

					file.getline(buffer, 1024, '\n');
					std::sscanf(buffer + 13, "%f, %f, %f, %f", &lightpos.row4.x, &lightpos.row4.y, &lightpos.row4.z, &lightpos.row4.w);

					std::cout << lightpos.row4.x << " " << lightpos.row4.y << " " << lightpos.row4.z << " " << lightpos.row4.w << std::endl;

					if (std::strcmp(name.c_str(), "Spot") == 0) {
						spotLights.push_back(lightpos);
					}
					else if (std::strcmp(name.c_str(), "Point") == 0) {
						pointLights.push_back(lightpos);
					}

					std::cout << "LIGHT READ" << std::endl;
				}
			}
		}
		file.close();
	}
	// TODO: Part 1c

	// TODO: Part 2b
	struct SHADER_VARS {
		GW::MATH::GVECTORF camera;
		GW::MATH::GMATRIXF view;
		unsigned MeshID;
		unsigned ModelID;
		float fluff[10];
	};

	// TODO: Part 2f
	Renderer(GW::SYSTEM::GWindow _win, GW::GRAPHICS::GVulkanSurface _vlk)
	{
		win = _win;
		vlk = _vlk;

		unsigned int width, height;
		win.GetClientWidth(width);
		win.GetClientHeight(height);
		// TODO: Part 4a
		mkb.Create(win);
		xbox.Create();
		// TODO: Part 2a
		math.Create();
		math2.Create();


		/***************** GEOMETRY INTIALIZATION ******************/
		// Grab the device & physical device so we can allocate some stuff
		VkPhysicalDevice physicalDevice = nullptr;
		vlk.GetDevice((void**)&device);
		vlk.GetPhysicalDevice((void**)&physicalDevice);

		//////////////////////////////////////////////////////////
		ReadGameLevel("../Assets/LevelFiles/GameLevel2.txt");
		// create the data

		// View Matrix;
		math.InverseF(TheCamera, viewMatrix);

		// projection matrix
		float AspR = 0;
		vlk.GetAspectRatio(AspR);
		math.ProjectionVulkanLHF(1.13446, AspR, 0.1, 100, projectionMatrix);

		// create light direction and colors

		push.lightColor = { 1.0f, 1.0f, 0.5f, 1.0f };
		push.lightDirection = { 1, -1, 0.3f, 1 };
		push.spotLightDirection = { 0, -1, 0, 1 };
		push.pointColor = { 0.0f, 0.0f, 5.0f, 5.0f };
		push.spotColor = { 10.0f, 0.0f, 0.0f, 10.0f };

		for (int i = 0; i < models.size(); i++)
		{

			GvkHelper::create_buffer(physicalDevice, device, sizeof(Model::Vertex) * (models[i].vertexCount),
				VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
				VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &models[i].vHandle, &models[i].vData);
			GvkHelper::write_to_buffer(device, models[i].vData, models[i].vertices.data(), sizeof(Model::Vertex) * (models[i].vertexCount));

			GvkHelper::create_buffer(physicalDevice, device, sizeof(unsigned) * (models[i].indexCount),
				VK_BUFFER_USAGE_INDEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
				VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &models[i].iHandle, &models[i].iData);
			GvkHelper::write_to_buffer(device, models[i].iData, models[i].indices.data(), sizeof(unsigned) * models[i].indexCount);
		}

		push.projectionMatrix = projectionMatrix;


		for (int i = 0; i < MAX_MODELS_IN_SCENE; i++)
		{
			if (i < models.size()) {
				push.ModelData[i] = models[i].uniform;
				models[i].ModelID = i;
			}
		}
		for (int i = 0; i < 10; i++)
		{
			if (i < spotLights.size()) { push.spotLights[i] = spotLights[i]; }
			if (i < pointLights.size()) { push.pointLights[i] = pointLights[i]; }
		}

		unsigned imageCount;
		vlk.GetSwapchainImageCount(imageCount);		
		constantBuffers.resize(imageCount);
		constantData.resize(imageCount);
		for (int i = 0; i < imageCount; i++)
		{
			GvkHelper::create_buffer(physicalDevice, device, sizeof(push),
				VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT |
				VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &constantBuffers[i], &constantData[i]);
			GvkHelper::write_to_buffer(device, constantData[i], &push, sizeof(push));
		}


		/////////////////////////////////////////////////////

		/***************** SHADER INTIALIZATION ******************/
		/***************** SHADER INTIALIZATION ******************/
		// Intialize runtime shader compiler HLSL -> SPIRV
		shaderc_compiler_t compiler = shaderc_compiler_initialize();
		shaderc_compile_options_t options = shaderc_compile_options_initialize();
		shaderc_compile_options_set_source_language(options, shaderc_source_language_hlsl);
		shaderc_compile_options_set_invert_y(options, false); // TODO: Part 2i
#ifndef NDEBUG
		shaderc_compile_options_set_generate_debug_info(options);
#endif
		// Create Vertex Shader
		shaderc_compilation_result_t result = shaderc_compile_into_spv( // compile
			compiler, vertexShaderSource, strlen(vertexShaderSource),
			shaderc_vertex_shader, "main.vert", "main", options);
		if (shaderc_result_get_compilation_status(result) != shaderc_compilation_status_success) // errors?
			std::cout << "Vertex Shader Errors: " << shaderc_result_get_error_message(result) << std::endl;
		GvkHelper::create_shader_module(device, shaderc_result_get_length(result), // load into Vulkan
			(char*)shaderc_result_get_bytes(result), &vertexShader);
		shaderc_result_release(result); // done
		// Create Pixel Shader
		result = shaderc_compile_into_spv( // compile
			compiler, pixelShaderSource, strlen(pixelShaderSource),
			shaderc_fragment_shader, "main.frag", "main", options);
		if (shaderc_result_get_compilation_status(result) != shaderc_compilation_status_success) // errors?
			std::cout << "Pixel Shader Errors: " << shaderc_result_get_error_message(result) << std::endl;
		GvkHelper::create_shader_module(device, shaderc_result_get_length(result), // load into Vulkan
			(char*)shaderc_result_get_bytes(result), &pixelShader);
		shaderc_result_release(result); // done
		// Free runtime shader compiler resources
		shaderc_compile_options_release(options);
		shaderc_compiler_release(compiler);

		/***************** PIPELINE INTIALIZATION ******************/
		// Create Pipeline & Layout (Thanks Tiny!)
		VkRenderPass renderPass;
		vlk.GetRenderPass((void**)&renderPass);
		VkPipelineShaderStageCreateInfo stage_create_info[2] = {};
		// Create Stage Info for Vertex Shader
		stage_create_info[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
		stage_create_info[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
		stage_create_info[0].module = vertexShader;
		stage_create_info[0].pName = "main";
		// Create Stage Info for Fragment Shader
		stage_create_info[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
		stage_create_info[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
		stage_create_info[1].module = pixelShader;
		stage_create_info[1].pName = "main";
		// Assembly State
		VkPipelineInputAssemblyStateCreateInfo assembly_create_info = {};
		assembly_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
		assembly_create_info.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
		assembly_create_info.primitiveRestartEnable = false;
		// TODO: Part 1e
		// Vertex Input State
		VkVertexInputBindingDescription vertex_binding_description = {};
		vertex_binding_description.binding = 0;
		vertex_binding_description.stride = sizeof(Model::Vertex);
		vertex_binding_description.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
		VkVertexInputAttributeDescription vertex_attribute_description[3] = {
			{ 0, 0, VK_FORMAT_R32G32B32_SFLOAT, 0 }, {1, 0, VK_FORMAT_R32G32B32_SFLOAT, 12}, {2, 0, VK_FORMAT_R32G32B32_SFLOAT, 24} //uv, normal, etc....
		};
		VkPipelineVertexInputStateCreateInfo input_vertex_info = {};
		input_vertex_info.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
		input_vertex_info.vertexBindingDescriptionCount = 1;
		input_vertex_info.pVertexBindingDescriptions = &vertex_binding_description;
		input_vertex_info.vertexAttributeDescriptionCount = 3;
		input_vertex_info.pVertexAttributeDescriptions = vertex_attribute_description;
		// Viewport State (we still need to set this up even though we will overwrite the values)
		VkViewport viewport = {
			0, 0, static_cast<float>(width), static_cast<float>(height), 0, 1
		};
		VkRect2D scissor = { {0, 0}, {width, height} };
		VkPipelineViewportStateCreateInfo viewport_create_info = {};
		viewport_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
		viewport_create_info.viewportCount = 1;
		viewport_create_info.pViewports = &viewport;
		viewport_create_info.scissorCount = 1;
		viewport_create_info.pScissors = &scissor;
		// Rasterizer State
		VkPipelineRasterizationStateCreateInfo rasterization_create_info = {};
		rasterization_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
		rasterization_create_info.rasterizerDiscardEnable = VK_FALSE;
		rasterization_create_info.polygonMode = VK_POLYGON_MODE_FILL;
		rasterization_create_info.lineWidth = 1.0f;
		rasterization_create_info.cullMode = VK_CULL_MODE_BACK_BIT;
		rasterization_create_info.frontFace = VK_FRONT_FACE_CLOCKWISE;
		rasterization_create_info.depthClampEnable = VK_FALSE;
		rasterization_create_info.depthBiasEnable = VK_FALSE;
		rasterization_create_info.depthBiasClamp = 0.0f;
		rasterization_create_info.depthBiasConstantFactor = 0.0f;
		rasterization_create_info.depthBiasSlopeFactor = 0.0f;
		// Multisampling State
		VkPipelineMultisampleStateCreateInfo multisample_create_info = {};
		multisample_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
		multisample_create_info.sampleShadingEnable = VK_FALSE;
		multisample_create_info.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
		multisample_create_info.minSampleShading = 1.0f;
		multisample_create_info.pSampleMask = VK_NULL_HANDLE;
		multisample_create_info.alphaToCoverageEnable = VK_FALSE;
		multisample_create_info.alphaToOneEnable = VK_FALSE;
		// Depth-Stencil State
		VkPipelineDepthStencilStateCreateInfo depth_stencil_create_info = {};
		depth_stencil_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
		depth_stencil_create_info.depthTestEnable = VK_TRUE;
		depth_stencil_create_info.depthWriteEnable = VK_TRUE;
		depth_stencil_create_info.depthCompareOp = VK_COMPARE_OP_LESS;
		depth_stencil_create_info.depthBoundsTestEnable = VK_FALSE;
		depth_stencil_create_info.minDepthBounds = 0.0f;
		depth_stencil_create_info.maxDepthBounds = 1.0f;
		depth_stencil_create_info.stencilTestEnable = VK_FALSE;
		// Color Blending Attachment & State
		VkPipelineColorBlendAttachmentState color_blend_attachment_state = {};
		color_blend_attachment_state.colorWriteMask = 0xF;
		color_blend_attachment_state.blendEnable = VK_FALSE;
		color_blend_attachment_state.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_COLOR;
		color_blend_attachment_state.dstColorBlendFactor = VK_BLEND_FACTOR_DST_COLOR;
		color_blend_attachment_state.colorBlendOp = VK_BLEND_OP_ADD;
		color_blend_attachment_state.srcAlphaBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
		color_blend_attachment_state.dstAlphaBlendFactor = VK_BLEND_FACTOR_DST_ALPHA;
		color_blend_attachment_state.alphaBlendOp = VK_BLEND_OP_ADD;
		VkPipelineColorBlendStateCreateInfo color_blend_create_info = {};
		color_blend_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
		color_blend_create_info.logicOpEnable = VK_FALSE;
		color_blend_create_info.logicOp = VK_LOGIC_OP_COPY;
		color_blend_create_info.attachmentCount = 1;
		color_blend_create_info.pAttachments = &color_blend_attachment_state;
		color_blend_create_info.blendConstants[0] = 0.0f;
		color_blend_create_info.blendConstants[1] = 0.0f;
		color_blend_create_info.blendConstants[2] = 0.0f;
		color_blend_create_info.blendConstants[3] = 0.0f;
		// Dynamic State 
		VkDynamicState dynamic_state[2] = {
			// By setting these we do not need to re-create the pipeline on Resize
			VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR
		};
		VkPipelineDynamicStateCreateInfo dynamic_create_info = {};
		dynamic_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
		dynamic_create_info.dynamicStateCount = 2;
		dynamic_create_info.pDynamicStates = dynamic_state;

		// TODO: Part 2e
		VkDescriptorSetLayoutBinding binding = { 0, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, nullptr };
		VkDescriptorSetLayoutCreateInfo wow = { VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO, nullptr, 0, 1, &binding };
		VkResult Vresult = vkCreateDescriptorSetLayout(device, &wow, nullptr, &setlayoutdesc);
		assert(Vresult == VkResult::VK_SUCCESS);
		// TODO: Part 2f
			// TODO: Part 4f
		VkDescriptorPoolSize haha = { VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, imageCount }; // change to max frames
		VkDescriptorPoolCreateInfo poolCreateinfo = { VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO, nullptr, 0, imageCount, 1, &haha };
		Vresult = vkCreateDescriptorPool(device, &poolCreateinfo, nullptr, &daPool);
		assert(Vresult == VkResult::VK_SUCCESS);



		// TODO: Part 2g
			// TODO: Part 4f
		VkDescriptorSetAllocateInfo allocate = {};
		allocate.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
		allocate.pNext = nullptr;
		allocate.descriptorPool = daPool;
		allocate.descriptorSetCount = 1;
		allocate.pSetLayouts = &setlayoutdesc;
		daSet.resize(imageCount);
		for (int i = 0; i < imageCount; i++)
		{
			
			VkResult result = vkAllocateDescriptorSets(device, &allocate, &daSet[i]);
			assert(result == VkResult::VK_SUCCESS);
		}



		// TODO: Part 2h
			// TODO: Part 4f

		
		

		VkWriteDescriptorSet writeDescSet = {};
		writeDescSet.descriptorCount = 1;
		writeDescSet.pNext = NULL;
		writeDescSet.dstBinding = 0;
		writeDescSet.dstArrayElement = 0;
		writeDescSet.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
		writeDescSet.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;

		for (int i = 0; i < imageCount; ++i) {
			VkDescriptorBufferInfo bufferinfo = {};
			bufferinfo.buffer = constantBuffers[i];
			bufferinfo.offset = 0;
			bufferinfo.range = VK_WHOLE_SIZE;
			writeDescSet.dstSet = daSet[i];
			writeDescSet.pBufferInfo = &bufferinfo;
			
			vkUpdateDescriptorSets(device, 1, &writeDescSet, 0, nullptr);
			
		}
		


		VkPushConstantRange push_constant_info = {};
		push_constant_info.offset = 0;
		push_constant_info.size = sizeof(SHADER_VARS);
		push_constant_info.stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;
		// Descriptor pipeline layout
		VkPipelineLayoutCreateInfo pipeline_layout_create_info = {};
		pipeline_layout_create_info.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
		// TODO: Part 2e
		pipeline_layout_create_info.setLayoutCount = 1;
		pipeline_layout_create_info.pSetLayouts = &setlayoutdesc;
		// TODO: Part 3c
		pipeline_layout_create_info.pushConstantRangeCount = 1;
		pipeline_layout_create_info.pPushConstantRanges = &push_constant_info;
		vkCreatePipelineLayout(device, &pipeline_layout_create_info,
			nullptr, &pipelineLayout);
		// Pipeline State... (FINALLY) 
		VkGraphicsPipelineCreateInfo pipeline_create_info = {};
		pipeline_create_info.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
		pipeline_create_info.stageCount = 2;
		pipeline_create_info.pStages = stage_create_info;
		pipeline_create_info.pInputAssemblyState = &assembly_create_info;
		pipeline_create_info.pVertexInputState = &input_vertex_info;
		pipeline_create_info.pViewportState = &viewport_create_info;
		pipeline_create_info.pRasterizationState = &rasterization_create_info;
		pipeline_create_info.pMultisampleState = &multisample_create_info;
		pipeline_create_info.pDepthStencilState = &depth_stencil_create_info;
		pipeline_create_info.pColorBlendState = &color_blend_create_info;
		pipeline_create_info.pDynamicState = &dynamic_create_info;
		pipeline_create_info.layout = pipelineLayout;
		pipeline_create_info.renderPass = renderPass;
		pipeline_create_info.subpass = 0;
		pipeline_create_info.basePipelineHandle = VK_NULL_HANDLE;
		vkCreateGraphicsPipelines(device, VK_NULL_HANDLE, 1,
			&pipeline_create_info, nullptr, &pipeline);

		/***************** CLEANUP / SHUTDOWN ******************/
		// GVulkanSurface will inform us when to release any allocated resources
		shutdown.Create(vlk, [&]() {
			if (+shutdown.Find(GW::GRAPHICS::GVulkanSurface::Events::RELEASE_RESOURCES, true)) {
				CleanUp(); // unlike D3D we must be careful about destroy timing
			}
			});
	}
	void Update()
	{
		unsigned int currentBuffer;
		vlk.GetSwapchainCurrentImage(currentBuffer);
		GvkHelper::write_to_buffer(device,
			constantData[currentBuffer], &push, sizeof(ALL_SHADER_MODEL_DATA));
	}
	void Render() {
		Update();
		for (int i = 0; i < models.size(); i++)
		{
			RenderModel(models[i]);
		}

		
		
	}

	void RenderModel(Model& object)
	{

		// TODO: Part 4d
		// grab the current Vulkan commandBuffer
		unsigned int currentBuffer;
		vlk.GetSwapchainCurrentImage(currentBuffer);
		VkCommandBuffer commandBuffer;
		vlk.GetCommandBuffer(currentBuffer, (void**)&commandBuffer);
		// what is the current client area dimensions?
		unsigned int width, height;
		win.GetClientWidth(width);
		win.GetClientHeight(height);
		// setup the pipeline's dynamic settings
		VkViewport viewport = {
			0, 0, static_cast<float>(width), static_cast<float>(height), 0, 1
		};
		VkRect2D scissor = { {0, 0}, {width, height} };
		vkCmdSetViewport(commandBuffer, 0, 1, &viewport);
		vkCmdSetScissor(commandBuffer, 0, 1, &scissor);
		vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);

		// now we can draw
		VkDeviceSize offsets[] = { 0 };
	
		// TODO: Part 4d
		// TODO: Part 2i
		GvkHelper::write_to_buffer(device, constantData[currentBuffer], &push, sizeof(ALL_SHADER_MODEL_DATA));
		vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineLayout, 0, 1, &daSet[currentBuffer], 0, nullptr);

		vkCmdBindVertexBuffers(commandBuffer, 0, 1, &object.vHandle, offsets);
		// TODO: Part 1h
		vkCmdBindIndexBuffer(commandBuffer, object.iHandle, 0, VK_INDEX_TYPE_UINT32);
		// TODO: Part 3b
			// TODO: Part 3d
		math.InverseF(viewMatrix, TheCamera);
		for (int i = 0; i < object.meshCount; i++)
		{
			SHADER_VARS stuff = { TheCamera.row4, viewMatrix, object.meshData[i].materialIndex, object.ModelID };
			vkCmdPushConstants(commandBuffer, pipelineLayout, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(SHADER_VARS), &stuff);
			vkCmdDrawIndexed(commandBuffer, object.meshData[i].indexCount, 1, object.meshData[i].indexOffset, 0, 0);  // TODO: Part 1d, 1h
			
			//vkCmdDraw(commandBuffer,3, 1, 0, 0);  // TODO: Part 1d, 1h
		}
	}

	//for (int i = 0; i < models[0].meshCount; i++)
	//{
	//	SHADER_VARS stuff = { viewMatrix, models[0].meshData[i].materialIndex, models[0].ModelID };
	//	vkCmdPushConstants(commandBuffer, pipelineLayout, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(SHADER_VARS), &stuff);
	//	vkCmdDrawIndexed(commandBuffer, models[0].meshData[i].indexCount, models[0].indexCount, models[0].meshData[i].indexOffset, 0, 0);  // TODO: Part 1d, 1h
	//}

	// TODO: Part 4b
	std::chrono::steady_clock::time_point UpdateCamera(std::chrono::steady_clock::time_point& start) {
		auto end = std::chrono::steady_clock::now();
		std::chrono::duration<double> time = end - start;

		GW::MATH::GMATRIXF camera; math.InverseF(viewMatrix, camera); // grab view matrix and inverse for camera matrix

		float camera_speed = 0.6f;
		GW::INPUT::GController::EVENT_DATA controller;
		controller.controllerIndex = 0;
		float spacestate = 0; float shiftstate = 0; float ltriggerstate = 0; float rtriggerstate = 0;
		mkb.GetState(G_KEY_SPACE, spacestate);
		mkb.GetState(G_KEY_LEFTSHIFT, shiftstate);
		xbox.GetState(controller.controllerIndex, G_RIGHT_TRIGGER_AXIS, rtriggerstate);
		xbox.GetState(controller.controllerIndex, G_LEFT_TRIGGER_AXIS, ltriggerstate);

		float total_Y_Change = spacestate - shiftstate + rtriggerstate - ltriggerstate;

		camera.row4.y += total_Y_Change * camera_speed * time.count();

		float PerFrameSpeed = camera_speed * time.count();
		float wstate, sstate, lystickstate, dstate, astate, lxstickstate;
		mkb.GetState(G_KEY_W, wstate);
		mkb.GetState(G_KEY_S, sstate);
		mkb.GetState(G_KEY_D, dstate);
		mkb.GetState(G_KEY_A, astate);

		lystickstate = 0;
		lxstickstate = 0;
		xbox.GetState(controller.controllerIndex, G_LY_AXIS, lystickstate);
		xbox.GetState(controller.controllerIndex, G_LX_AXIS, lxstickstate);


		float total_Z_change = wstate - sstate + lystickstate;
		float total_X_change = dstate - astate + lxstickstate;
		GW::MATH::GVECTORF v;
		v.x = total_X_change * PerFrameSpeed;
		v.y = 0;
		v.z = total_Z_change * PerFrameSpeed;
		v.w = 0;
		GW::MATH::GMATRIXF newMatrix;
		math.TranslateLocalF(GW::MATH::GIdentityMatrixF, v, newMatrix);
		math.MultiplyMatrixF(newMatrix, camera, camera);


		// TODO: Part 4f
		float rightystickstate = 0;
		xbox.GetState(controller.controllerIndex, G_RY_AXIS, rightystickstate);

		float thumb_speed = 0.7 * time.count();
		float x;
		float y;
		unsigned int height;
		win.GetClientHeight(height);
		GW::GReturn result;
		result = mkb.GetMouseDelta(x, y);
		// bug that lets redundant inputs still pass through occurs if controller and mouse is used at the same time.
		if (result != GW::GReturn::REDUNDANT || rightystickstate != 0)
		{
			float total_pitch = 1.13446 * y / height + rightystickstate * -thumb_speed;
			math.RotateXLocalF(GW::MATH::GIdentityMatrixF, total_pitch, newMatrix);
			math.MultiplyMatrixF(newMatrix, camera, camera);
		}

		// TODO: Part 4g
		float rightxstickstate = 0;
		xbox.GetState(controller.controllerIndex, G_RX_AXIS, rightxstickstate);
		GW::MATH::GVECTORF savePos = camera.row4;
		unsigned int width;
		win.GetClientHeight(width);
		float AspR;
		vlk.GetAspectRatio(AspR);

		if (result != GW::GReturn::REDUNDANT || rightxstickstate != 0) {
			float total_yaw = 1.13446 * AspR * x / width + rightxstickstate * thumb_speed;
			math.RotateYGlobalF(GW::MATH::GIdentityMatrixF, total_yaw, newMatrix);
			math.MultiplyMatrixF(camera, newMatrix, camera);
			camera.row4 = savePos;
		}

		// TODO: Part 4c
		math.InverseF(camera, viewMatrix);
		auto begin = std::chrono::steady_clock::now();
		return begin;
	}

private:
	void CleanUp()
	{
		// wait till everything has completed
		vkDeviceWaitIdle(device);
		// Release allocated buffers, shaders & pipeline
		// TODO: Part 1g
		for (int i = 0; i < models.size(); i++)
		{
			vkDestroyBuffer(device, models[i].vHandle, nullptr);
			vkFreeMemory(device, models[i].vData, nullptr);
			vkDestroyBuffer(device, models[i].iHandle, nullptr);
			vkFreeMemory(device, models[i].iData, nullptr);
		}
		for (int i = 0; i < constantBuffers.size(); i++)
		{
			vkDestroyBuffer(device, constantBuffers[i], nullptr);
			vkFreeMemory(device, constantData[i], nullptr);
		}
		constantData.clear();
		constantBuffers.clear();
		vkDestroyShaderModule(device, vertexShader, nullptr);
		vkDestroyShaderModule(device, pixelShader, nullptr);
		// TODO: Part 2e
		vkDestroyDescriptorSetLayout(device, setlayoutdesc, nullptr);
		// TODO: part 2f
		vkDestroyDescriptorPool(device, daPool, nullptr);
		vkDestroyPipelineLayout(device, pipelineLayout, nullptr);
		vkDestroyPipeline(device, pipeline, nullptr);


	}
};
