Keyboard & Mouse: wasd to move, mouse to look, shift to descend, space to ascend
CONTROLLER: triggers to descend and ascend, sticks to look and move.

don't use both at the same time or the camera gets sick.